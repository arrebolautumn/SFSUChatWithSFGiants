/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment02PartB;

/**
 *
 * @author lien
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import java.io.*;

/**
 *
 * @author lien
 */

public class StdOutStdErrTee extends OutputStream {

    //
    private String stdOutFilePath;
    private String stdErrFilePath;
    private static File objOutFile; // Object for OutPut log file
    private static File objErrFile; //Object for Error log file
    private static File objReceiptFile;
    private OutputStream[] streamsToConsoleToFile;
    // Static Data Fields
    //
    public StdOutStdErrTee() {

    }

    // Instance Data Fields
    //

    //
    // Constructors
    //

    //
    // Instance Methods
    //
    public void startLog() {
        objOutFile = new  java.io.File(getStdOutFilePath());
            if (!objOutFile.exists()){
                try{
                    boolean create = objOutFile.createNewFile();
                }catch(IOException ex){
                    System.out.println("Fail to create Output File");
                }
            }

        objErrFile = new java.io.File(getStdErrFilePath());
            if (!objErrFile.exists()){
                try {
                    boolean create = objErrFile.createNewFile();
                }catch( IOException ex){
                    System.out.println("Fail to create Error File");
                }
            }
    }

    public  void stopLog() {
        this.writeToErrorFile ("\n" + "*" + "\n" + "**" + "\n" + "***" + "\n" + "***" + "\n"+ "*".repeat(80) +"\n"+"*".repeat(80));
    }public void writeToErrorFile(String message){
        try{
            PrintWriter print = new PrintWriter(new FileWriter(getStdErrFilePath(), true));
            print.write(message);
            print.close();
        }catch(IOException ex){
            System.out.println("Error while writing ErrorFile log "+ ex.getMessage());
        }
    }public void writeToOutFile(String message){
        try{
            PrintWriter print = new PrintWriter(new FileWriter(getStdOutFilePath(), true));
            print.write(message);
            print.close();
        }catch(IOException ex){
            System.out.println("Error while writing Output log "+ ex.getMessage());

        }
    }public void writeToReceiptFile(String message){
        try{
            PrintWriter print = new PrintWriter(new FileWriter(Receipt.getPath(),true) );
            print.write(message+"\n");
            print.close();
        }catch(IOException ex){
            System.out.println("Error while writing Receipt log "+ ex.getMessage());

        }

    }public void startReceiptLog(){
        objReceiptFile = new java.io.File(Receipt.getPath());
        if (!objReceiptFile.exists()){
            try{
                boolean create = objReceiptFile.createNewFile();
            }catch(IOException e){
                System.out.println("Fail to create Receipt File: "+ e.getMessage());
            }
        }
        writeToReceiptFile("\n" + "*".repeat(80) + "\n" + "*".repeat(80)+ "\n" + "*** Reading file: "+ Receipt.getName() + "\n" + "*** Relative path: "+Receipt.getPath()+ "\n" + "** " + "\n" + "* " + "\n");

    }

    public void write(int b) throws IOException {
        for (var out : this.streamsToConsoleToFile) {
            out.write(b);
            out.flush();
        }
    }public String getStdOutFilePath(){
        return "./src/assignment02PartB/log/StandardOut.log";

    }public String getStdErrFilePath(){

        return "./src/assignment02PartB/log/StandardErr.log";
    }
}
//
// Additional Methods
//

//
// Language
//

//
// Override
//

