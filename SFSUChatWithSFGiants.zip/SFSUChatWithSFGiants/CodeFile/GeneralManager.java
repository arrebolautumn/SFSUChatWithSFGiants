/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: GeneralManager.java
 * Author: Duc Ta
 * Author: <First Name> <Last Name>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

public final class GeneralManager extends Person {

    //
    // Instance Data Fields
    //

    //
    // Constructors
    //
    public GeneralManager() {
        super.setFirstName("Scott ");
        super.setLastName("Harris");
    }
    public  static String getFullName(){
        return "Scott Harris";
    }

    @Override
    public void sayGreeting() {
        System.out.println("Hello I'm a General Manager");

    }

    @Override
    public void sayGreeting(String string) {
        System.out.println("Hello " + string+"! I am a General Manager");
    }


    //
    // Instance Methods
    //

    //
    // Language
    //

    //
    // Override
    //
}