/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Club.java
 * @author: Duc Ta
 * @author: <First Name> <Last Name>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

public final class Club extends Organization {

    //
    // Instance Data Fields
    //
    private static String name;
    private  static String address;
    private static String officialSong;

    //
    // Constructors
    //
    public Club(String clubName) {
        setName(clubName);
        setAddress("Oracle Park"); // ballPark


    }

    //
    // Static Methods
    //
    public static void setName(String name){
        Club.name = name;
    }public static String getName(){
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();

        }else{
            need = Club.name;
        }
        {
            return need;
        }
    }
    public static void setAddress(String address){
        Club.address = address;
    }public static String getAddress(){
        return Club.address;
    }public static String getOfficialSong(){
        officialSong = "Take Me out to the Ball Game";
        return Club.officialSong;
    } public static String getShortName(){
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();

        }else{
            need = "SF Giants";
        }
        {
            return need;
        }
    }



    public static String getColor(){
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();

        }else{
            need ="Orange, Black, Gold, Cream";
        }
        {
            return need;
        }

    }public static String getBallpark(){
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();

        }else{
            need = "Oracle Park";
        }
        {
            return need;
        }
    }public static int getWorldSeriesTitles(){
        return 8;
    }public static int getNLPennants(){
        return 23;
    }public static int getDivisionTitles(){
        return 8;
    }public static int getWildCardBerths(){
        return 3;
    }public static String getOwners(){
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();

        }else{
            need = OwnerGroup.getName();
        }
        {
            return need;
        }
    }public static String getPresident(){
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();

        }else{
            need = President.getFullName();
        }
        {
            return need;
        }
    }public static String getGeneralManager(){
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();

        }else{
            need = GeneralManager.getFullName();
        }
        {
            return need;
        }
    }public static String getManager(){
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();

        }else{
            need = Manager.getFullName();
        }

        return need;
    }
    public static int getEstablishYear(){
        return 1883;
    }



    @Override
    public void displayAbout(){
        // displayAbout ???
    }

    public void displayMission(){
        // what mission ?

    }

    //
    // Instance Methods
    //

    //
    // Additional Instance Methods
    //

    //
    // Language
    //
}