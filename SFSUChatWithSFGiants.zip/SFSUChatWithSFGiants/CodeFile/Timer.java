/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Timer.java
 * @author: Duc Ta
 * @author: <First Name> <Last Name>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

import java.text.*;
import java.util.*;

public class Timer {



    //
    // Static Data Fields
    //
    private static String[] listOfTimeZone = {"PST","CST","EST"};
    private String timeZoneFormatted;
    //private static Timer TimeZOne;
    private  String timeZone="Pacific Standard Time in Day Light Saving";
    private static Timer TimerZonePreferenceObj;
    private static String userTimeZone="";
    private String shortName;
    private DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");





    public  Timer(String timZonePreference){
        String yo=Timer.getUserTimeZone();


        switch (yo) {

            case "PST":
            {

                dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

                this.timeZone  ="Pacific Standard Time in Day Light Saving";

                this.shortName = "PST";
                dateFormat.setTimeZone(TimeZone.getTimeZone("America/Los_Angeles"));
                Language.populateAlienPhrases(this.timeZone);
                timeZoneFormatted = dateFormat.format(new Date());
                break;
            }
            case "CST":
            {
                dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                this.timeZone ="Central Time Zone in Day Light Saving";

                this.shortName = "CST";

                dateFormat.setTimeZone(TimeZone.getTimeZone("America/Chicago"));
                timeZoneFormatted = dateFormat.format(new Date());
                break;
            }
            case "EST":
            {
                dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                this.timeZone ="Eastern Time Zone in Day Light Saving";
                this.shortName = "EST";

                dateFormat.setTimeZone(TimeZone.getTimeZone("America/New_York"));
                timeZoneFormatted = dateFormat.format(new Date());
                break;
            }
            default :
                break;
        }


    }
    public void translate(String text){
        if (Language.getMainLanguage().equals("alien")){
            if (text.length()<30){
                System.out.print(Language.getAlien().repeat(1) );
            }else if ((text.length()<40)||(text.length()>=30)){
                System.out.print(Language.getAlien().repeat(2) );

            }
        }

    }
    public  void setTimeZone(String userTiemZone){
        this.timeZone = userTiemZone;
    }
    public String getTimeZone(){
        return this.timeZone;
    }public String getTimeZoneFormatted(){
        String need;
        Language.populateAlienPhrases(this.timeZone);
        if (Language.getMainLanguage().equals("alien")){
            need=Language.getAlien().repeat(1);
        }
        else{
            need = this.timeZone;
        }
        return need;

    }
    // GET DATE FORMAT
    public String getDateFormat(){
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss aa");

        switch (this.shortName) {
            case "PST":

                dateFormat.setTimeZone(TimeZone.getTimeZone("America/Los_Angeles"));

                break;
            case "EST":

                dateFormat.setTimeZone(TimeZone.getTimeZone("America/New_York"));


                break;
            case "CST":

                dateFormat.setTimeZone(TimeZone.getTimeZone("America/Chicago"));


                break;
            default:
                break;
        }
        return dateFormat.format(new Date());

    }public static String getUserTimeZone(){
        return Timer.userTimeZone;
    }

    public static Timer setTimeZonePreference(){
        Scanner input =new Scanner(System.in);
        boolean define=false;
        int countTime=0;


        while (define==false){
            try{
                String text1 ="Time Zone: ";

                if (Language.getMainLanguage().equals("alien")){
                    Language.populateAlienPhrases(text1);

                }
                else{
                    Language.populateEnglishPhrases(text1);
                }
                Timer.userTimeZone = input.nextLine().toUpperCase();
                for (int p=0;p<listOfTimeZone.length;p++){
                    if (Timer.userTimeZone .equals(listOfTimeZone[p])){
                        countTime++;
                        define=true;

                        break;
                    }

                }//System.out.println(countTime);

                if (countTime==0){

                    throw new InputMismatchException();
                }else{
                    break;
                }



            }catch (InputMismatchException ex){
                String text1;
                String text2;
                if (Language.getMainLanguage().equals("alien")){
                    text1=Language.getAlien();
                    text2=Language.getAlien();
                }else{
                    text1="INVALID time zone. Plesase enter your time zone.";
                    text2="Please choose among: ";
                }
                System.out.println(text1);
                System.out.println(text2 + "PST/ CST/ EST ");
            }

        }


        switch(Timer.userTimeZone){
            case "PST":
                TimerZonePreferenceObj=new Timer(userTimeZone);
                break;
            case "CST":
                TimerZonePreferenceObj=new Timer(userTimeZone);
                break;
            case "EST":
                TimerZonePreferenceObj=new Timer(userTimeZone);
                break;

        }



        return Timer.TimerZonePreferenceObj ;



    }
}

//
// Instance Data Fields
//


//
// Additional Instance Methods
//

//
// Language
//


