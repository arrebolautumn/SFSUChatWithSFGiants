/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Directory.java
 * Author: Duc Ta
 * Author: <First Name> <Last Name>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

public final class Directory {

    //
    // Static Data Fields
    //

    //
    // Instance Data Fields
    //

    //
    // Constructors
    //





    public String getPath() {
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need=Language.getAlien();
        }else{
            need="./src/assignment02PartB/log/Receipt-*-*.log ";
        }
        return need;
    }


}
