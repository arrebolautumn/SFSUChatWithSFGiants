package assignment02PartB;

public class Receipt {
    private static String name;
    private static String path;
    private static String email;
    Receipt(String name, String email){
       Receipt.name=name;
        Receipt.email=email;
        path = Config.getDefaultLogDirectoryPath()+getName()+".log";

    }public static String getName(){
        return Receipt.name.toUpperCase()+"_"+Receipt.email.toUpperCase();
    }public static String getPath(){
        return path;
    }
}

