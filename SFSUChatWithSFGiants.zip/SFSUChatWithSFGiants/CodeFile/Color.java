/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Color.java
 * @author: Duc Ta
 * @author: <First Name> <Last Name>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

public final class Color {

    //
    // Static Data Fields
    //
    private static final String ANSI_RESET = "\u001B[0m";
    private static final String ANSI_YELLOW = "\u001B[33m";
    private static final String ANSI_PURPLE_BACKGROUND = "\u001B[45m";

    //
    // Instance Data Fields
    //

    //
    // Constructors
    //
    public Color() {



    }public String getColorSequences(){
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();
        }else {
            need = "ANSI";
        }

        return need;
    } public static String getBackground(){
        return ANSI_PURPLE_BACKGROUND;
    }public static String getReset(){
        return ANSI_RESET;
    }public static String getYellow(){
        return   ANSI_YELLOW ;
    }


    //
    // Static Methods
    //

    //
    // Instance Methods
    //

    //
    // Language
    //
}