/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Quiz.java
 * Author: Duc Ta
 * Author: <First Name> <Last Name>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"
import java.util.*;
public final class Quiz {

    //
    // Instance Data Fields
    //
    private static QuestionAnswer QA1 = new QuestionAnswer();
    private static QuestionAnswer QA2 = new QuestionAnswer();
    private static QuestionAnswer QA3 = new QuestionAnswer();
    private static QuestionAnswer QA4 = new QuestionAnswer();
    private static QuestionAnswer QA5 = new QuestionAnswer();
    private static QuestionAnswer QA6 = new QuestionAnswer();
    private static int correctTime=0;


    private static  QuestionAnswer[] questionsRepresentation = {QA1,QA2,QA3,QA4,QA5,QA6};
    private static String[] questions = {"Which type of class has 'protected' constructors?",
            "What type of method did Java 8 add to 'interface'?",
            "What new keyword did Java 13 add to 'switch' statement?",
            "In Java 15, what keyword pairs with 'sealed'?",
            "Giants in Spanish?","Take me out to the...?"};
    private static String[] questionsInAlien={Language.getAlien(),Language.getAlien(),
            Language.getAlien(),Language.getAlien(),Language.getAlien(),Language.getAlien()};

    private static String[] userAnswers=new String[6];
    private static String[] correctAnswers = {"abstract","default","yield","permits","gigantes","ball games"};
    private static String studentName;
    //
    // Constructors
    //
    public Quiz() {

    }
    public static void AnswerThis(){
        String text1;
        String text2;
        String text3;
        String text4;
        String text5;


        if (Language.getMainLanguage().equals("alien")){
            text1= Language.getAlien();
            text2= Language.getAlien();
            text3= Language.getAlien();
            text4= Language.getAlien();
            text5= Language.getAlien();



        }else{
            text1="SF Giants: ";
            text2="SF Giants: Correct!";
            text3="SF Giants: Oop . . .";
            text4="___ Please try again at your graduation ceremony. ___";
            text5="*** Congrats! You won FREE TICKETS to SF GIANTS Games ***";
        }
        Scanner input = new Scanner(System.in);
        for (int i=0;i<questionsRepresentation.length;i++){
            questionsRepresentation[i].setQuestion(questions[i]);
            questionsRepresentation[i].setCorrectAnswer(correctAnswers[i]);



        }
        if (Language.getMainLanguage().equals("alien")){
            for (int i=0;i<questionsInAlien.length;i++){
                System.out.println(text1+questionsInAlien[i].repeat(3));
                System.out.print(Quiz.getStudentName()+": ");
                Quiz.userAnswers[i]=input.nextLine().toLowerCase();
                if (Quiz.userAnswers[i].equals(correctAnswers[i])){
                    correctTime++;
                    System.out.println(text2);
                }else{
                    System.out.println(text3);

                }

            }
        }else{
            for (int i=0;i<questions.length;i++){
                System.out.println(text1+questions[i]);
                System.out.print(Quiz.getStudentName()+": ");
                Quiz.userAnswers[i]=input.nextLine().toLowerCase();
                if (Quiz.userAnswers[i].equals(correctAnswers[i])){
                    correctTime++;
                    System.out.println(text2);
                }else{
                    System.out.println(text3);

                }
            }

        }
        if (correctTime<5){
            System.out.println(text4);
            ChatSession.stdOutStdErrTee.writeToReceiptFile(text4);
        }else{
            System.out.println(text5);
            ChatSession.stdOutStdErrTee.writeToReceiptFile(text5);


        }


    }public static void setStudentName(String studentName){
        Quiz.studentName=studentName;
    }public static String getStudentName(){
        return Quiz.studentName;
    }

    //
    // Instance Methods
    //

    //
    // Additional Instance Methods
    //

    //
    // Language
    //
}