/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Language.java
 * @author: Duc Ta
 * @author: <First Name> <Last Name>
 * **********************************************
 */

package assignment02PartB;
import java.util.*;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

// java.util.ResourceBundle
// - ResourceBundle is a valid approach to internationalization.
// - ResourceBundle is not required.
// - Other approaches to internationalization are available. Some of these approaches are
// more straightforward and more relevant to new CSC 220 students then ResourceBundle is.
// - Yet, curiosity for intelligence is always highly encouraged:
// https://docs.oracle.com/en/java/javase/16/docs/api/java.base/java/util/ResourceBundle.html

public final class Language {
    //
    // Static Data Fields
    //    
    private static final String defaultAlienSound = "~ ąļīæń ~ "; // Default
    private static Language userLanguage;
    private String[] greetingPhrases = {"Hello"};
    private  String[] configPhrases = {"-".repeat(70),"Language: ","Time Zone: ","Color Sequence: ","Standard Output Log: ",
            "Standard Error Log: ","Receipt Log: "," ","Default University: ","Default Club: "};
    private static String[] listOfLang = {"english", "alien"};
    private  String[] configPhrasesInAlien = {"-".repeat(70),Language.getAlien(),Language.getAlien(),Language.getAlien()
            ,Language.getAlien(),Language.getAlien(),Language.getAlien(),Language.getAlien(),Language.getAlien(),Language.getAlien()};
    /*private  String[] configPhrasesInViet={"Ngôn Ngữ: ", "Múi Giờ: ","Màu Sắc: ","Đầu Ra : ","Lỗi: ","Thông tin Cụ thể: "
    ,"Trường Đại Học","Câu Lạc Bộ: "};*/
    //
    // Instance Data Fields
    //
//private String UniversityPhrase = "San Francisco State University";
    private  String[] ClubPhrase = {"San Francisco Giants"};
    private static String UltiLanguage=null;
    private  String[] UniversityPhrases = {"San Francisco State Universitity"};
    //
    // Constructors
    //

    public Language(String newLanguage) {


        UltiLanguage = newLanguage.toLowerCase();
        if (UltiLanguage.equals("alien")) {
            //case "alien" -> this.populateAlienPhrases();            // Supported
            //default -> this.populateEnglishPhrases();               // Supported
            //populateAlienPhrases();
        }else if (UltiLanguage.equals("english")){
            //populateEnglishPhrases();

        }


    }

    public Language() {


    }

    // alien phrases

    public static void populateAlienPhrases(String text) {

        if (Language.getMainLanguage().equals("alien")){
            if (text.length()<30){
                System.out.print(Language.getAlien().repeat(1) );
            }else if ((text.length()<40)||(text.length()>=30)){
                //System.out.print(Language.getAlien().repeat(2) );

            }
        }




    }
    public static String getAlien(){
        return Language.defaultAlienSound;
    }
    public static void populateEnglishPhrases(String text) {
        //is default itself
        System.out.print(text);


    }


    public  String getUniversityPhrase(int num){
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need= Language.getAlien();

        }else{
            need =this.UniversityPhrases[num];
        }
        return need;
    } public  String getClubPhrase(int num){
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need= Language.getAlien();

        }else{
            need =this.ClubPhrase[num];
        }
        return need;


    }public static Language setLanguagePreference(){
        Scanner input = new Scanner(System.in);

/// over here
        int counLang=0;

        boolean define=false;
        String UserLanguage = "";
        while (define==false){
            try{
                System.out.print("Language: ");
                UserLanguage = input.nextLine().toLowerCase();
                for (String listOfLang1 : listOfLang) {
                    if (UserLanguage.equals(listOfLang1)) {
                        counLang++;
                        define=true;

                        break;
                    }
                } //System.out.println(counLang);

                if (counLang==0){

                    throw new InputMismatchException();
                }else{
                    break;
                }



            }catch (InputMismatchException ex){
                System.out.println("UNSUPPORTED LANGUAGE");
                System.out.println("PLESE CHOOSE AMONG: ENGLISH/ ALIEN");
            }

        }
        userLanguage = new Language(UserLanguage);

        //userLanguage = new Language();
        return userLanguage;


    }public static String getMainLanguage(){
        return Language.UltiLanguage;
    }
    public static  void displayAppHeader(){
        System.out.println(Config.getOfficialAppHeader());


    }public  String getConfigPhrase(int num){
        String need;
        switch (Language.getMainLanguage()) {
            case "alien":
                need = this.configPhrasesInAlien[num];
                break;

            default:
                need=this.configPhrases[num];
                break;
        }
        return need;

    }

    public String getGreetingPhrase(int i) {
        return greetingPhrases[i];
    }public String getLanguage(){
        String need= Language.UltiLanguage.toUpperCase();
        if (Language.getMainLanguage().equals("alien")){
            need=defaultAlienSound;
        }
        return need;
    }


}