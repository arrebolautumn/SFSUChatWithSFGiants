//    public static void generateSFGiantsCard(String recipient, String message, String senderFirstName, String senderEmail, char artSymbol, int artSize, String artFont) throws Exception
/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Card.java
 * @author: Duc Ta
 * @author: <First Name> <Last Name>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

public final class Card {

    //
    // Instance Data Fields
    //
    public static int artSize = 14;     // Please change artSize, if needed, to get an identical output
    private static String artFont = ""; // Please change artFont, if needed, to get an identical output
    private String recipient;
    private String message;
    private String senderFirstName;
    private String senderEmail;
    private char artSymbol;
    private static int numberOfCard;


    //
    // Constructors
    //
    public Card(String recipient, String message, String senderFirstName, String senderEmail, char artSymbol) {
        this.recipient =recipient;
        this.message =message;
        this.senderEmail = senderEmail;
        this.senderFirstName = senderFirstName;
        this.artSymbol = artSymbol;

    }public Card(){

    }
    public void getCard()  {
        try{
            SFGiantsCardGenerator.generateSFGiantsCard(getRecipient(), getMessage(), getSenderFirstName(),getSenderEmail(),getArtSymbol(),getArtSize(), getArtFont());
        }catch(Exception ex){
            System.out.print("");
        }

    }public static int getNumberOfCard(){
        return Card.numberOfCard;
    }public static void setNumberOfCard(int numberOfCard){
        Card.numberOfCard=numberOfCard;

    }

    public  String getRecipient(){
        return this.recipient;
    }public void setRecipient(String recipient){
        this.recipient=recipient;

    }
    public String getMessage(){
        return this.message;
    }public void setMessage(String message){
        this.message=message;

    }
    public String getSenderFirstName(){
        return this.senderFirstName;
    }public void setSenderFirstName(String sender){
        this.senderFirstName=sender;

    }
    public String getSenderEmail(){
        return this.senderEmail;
    }public void setSenderEmail(String sender){
        this.senderEmail=sender;

    }
    public char getArtSymbol(){
        return this.artSymbol;
    }public void setArtSymbol(char sender){
        this.artSymbol=sender;
    }


    public static int getArtSize() {
        return Card.artSize-4;
    }

    public  static String getArtFont() {
        return Card.artFont;

    }
//
    // Instance Methods
    //

    //
    // Additional Instance Methods
    //


    //
    // Language
    //

}
