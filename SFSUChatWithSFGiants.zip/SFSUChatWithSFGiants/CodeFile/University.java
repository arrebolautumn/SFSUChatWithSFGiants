/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: University.java
 * Author: Duc Ta
 * Author: <First Name> <Last Name>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

public final class University extends Organization {
    //
    // Static Data Fields
    //These are all ddefault value
    private static String name = "San Francisco State University";
    private static String address = "1600 Holloway Avenue, San Francisco, CA 94132";
    private static String latin;
    private static String english;
    private static String type = "public";
    private static int EstablishYear = 1899;
    private static String location = "San Francisco, California, United States";
    private static String colors= "Purple, Gold";
    private static String nickname = "Gators";
    private static String mascot = "Gator";
    private static String website = "www.sfsu.edu";

    //
    // Instance Data Fields
    //


    //
    // Constructors
    //
    public University(String name) {
        setAddress("1600 Holloway Avenue, San Francisco, CA 94132");
        //setName(nameOfUni);
        setLatin("Experientia Docet");
        setEnglish("Experience Teaches");
        setType("Public");
        setEstablishYear(1899);
        setLocation("San Francisco, California, United States");
        setColors("Purple, Gold");
        setNickname("Gators");
        setMascot("Gator");
        setWebsite("www.sfsu.edu");


    }

    @Override
    public  void displayAbout(){
        System.out.printf("%-25s %-50s %n", this.getPhrase(0), University.getName());
        System.out.printf("%-25s %-50s %n", this.getPhrase(1), University.getLatin());
        System.out.printf("%-25s %-50s %n", this.getPhrase(2), University.getEnglish());
        System.out.printf("%-25s %-50s %n", this.getPhrase(3), University.getType());
        System.out.printf("%-25s %-50s %n", this.getPhrase(4), University.getEstablishYear());
        System.out.printf("%-25s %-50s %n", this.getPhrase(5), University.getLocation());
        System.out.printf("%-25s %-50s %n", this.getPhrase(6), University.getAddress());
        System.out.printf("%-25s %-50s %n", this.getPhrase(7), University.getColors());
        System.out.printf("%-25s %-50s %n", this.getPhrase(8), University.getNickname());
        System.out.printf("%-25s %-50s %n", this.getPhrase(9), University.getMascot());
        System.out.printf("%-25s %-50s %n", this.getPhrase(10), University.getWebsite());
        System.out.println("-".repeat(70));


    }
    public  void displayMission(){

    }public String getPhrase(int num){
        String[] UniPhrases = new String[11];
        /*{"Official Name: ","Motto in Latin: ","Motto in English: ", "Type: ",
        "Year of Establishment: ","Location: ", "Address: ", "Colors: ", "Nickname: ", "Mascot: ", "Website: "};
        */
        if (Language.getMainLanguage().equals("alien")){
            UniPhrases[0]=Language.getAlien();
            UniPhrases[1]=Language.getAlien();
            UniPhrases[2]=Language.getAlien();
            UniPhrases[3]=Language.getAlien();
            UniPhrases[4]=Language.getAlien();
            UniPhrases[5]=Language.getAlien();
            UniPhrases[6]=Language.getAlien();
            UniPhrases[7]=Language.getAlien();
            UniPhrases[8]=Language.getAlien();
            UniPhrases[9]=Language.getAlien();
            UniPhrases[10]=Language.getAlien();


        }else{
            UniPhrases[0]="Official Name: ";
            UniPhrases[1]="Motto in Latin: ";
            UniPhrases[2]="Motto in English: ";
            UniPhrases[3]="Type: ";
            UniPhrases[4]="Year of Establishment: ";
            UniPhrases[5]="Location: ";
            UniPhrases[6]="Address: ";
            UniPhrases[7]="Colors: ";
            UniPhrases[8]="Nickname: ";
            UniPhrases[9]="Mascot: ";
            UniPhrases[10]= "Website: ";


        }
        return UniPhrases[num];


    }
    //
    // Instance Methods
    //



    public static String getWebsite() {
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();
        }else{
            need =  University.website;
        }
        return need;
    }

    public static void setWebsite(String website) {
        University.website = website;
    }

    public static String getMascot() {
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();
        }else{
            need =  University.mascot;
        }
        return need;
    }

    public static void setMascot(String mascot) {
        University.mascot = mascot;
    }

    public static String getNickname() {
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();
        }else{
            need =  University.nickname;
        }
        return need;

    }

    public static void setNickname(String nickname) {
        University.nickname = nickname;
    }

    public static String getColors() {
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();
        }else{
            need =  University.colors;
        }
        return need;

    }

    public static void setColors(String colors) {
        University.colors = colors;
    }

    public static String getLocation() {
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();
        }else{
            need =  University.location;;
        }
        return need;



    }

    public static void setLocation(String location) {
        University.location = location;
    }

    public static int getEstablishYear() {

        return University.EstablishYear;
    }

    public static void setEstablishYear(int establishYear) {
        University.EstablishYear = establishYear;
    }

    public static String getType() {
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();
        }else{
            need = University.type;
        }
        return need;


    }

    public static void setType(String type) {
        University.type = type;
    }

    public static String getEnglish() {
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();
        }else{
            need = University.english;
        }
        return need;

    }

    public static void setEnglish(String english) {
        University.english = english;
    }

    public static String getLatin() {
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();
        }else{
            need = University.latin;;
        }
        return need;

    }

    public static void setLatin(String latin) {
        University.latin = latin;
    }

    public static String getName() {
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();
        }else{
            need = University.name;
        }
        return need;
    }

    public static void setName(String name) {
        University.name = name;
    }

    public static String getAddress() {
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();
        }else{
            need =  University.address;
        }
        return need;



    }

    public static void setAddress(String address) {
        University.address = address;
    }
//
    // Additional Methods
    //

    //
    // Language
    //

    //
    // Override
    //
}