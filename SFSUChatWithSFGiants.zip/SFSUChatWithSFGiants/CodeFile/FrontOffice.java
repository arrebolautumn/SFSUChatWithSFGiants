/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: FrontOffice.java
 * Author: Duc Ta
 * Author: <First Name> <Last Name>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

import java.util.*;




// JAVA 15, 2020, added "sealed" and "permits" to Java classes.
// We are learning the new elements of JAVA 15.
// "sealed" and "permits" are used here so that we will have one more example to reference.
// We do not need to understand "sealed" and "permits" in order to start and complete this assignment.
public final class FrontOffice {

    //
    // Instance Data Fields
    //


    private static final String[] nameList = {"José Álvarez","Mauricio Dubón","Steven Duggar","Buster Posey","Caleb Baragar","Tyler Beede","John Brebbia","Kervin Castro"
            ,"Alex Cobb","Joey Bart","Curt Casali","Thairo Estrada","Mike Yastrzemski","Austin Slater","Tommy La Stella"};
    private static final String[] positionList={"Pitcher","Infielder","Outfielder","Catcher","Pitcher","Pitcher","Pitcher","Pitcher",
            "Pitcher","Catcher","Catcher","Outfielder","Outfielder","Infielder","Infielder"};
    private static final int[] numberList = {48,1,6,28,45,38,59,76,
            53,60,2,39,5,13,18};
    private static final String[] batsList = {"left", "right","left", "right","right","right","left","right",
            "right","right","right","right","left","right","left"};
    private static final String[] throwList={"left", "right", "right", "right","left","right","right","right",
            "right","right","right","right","left","right","right"};
    private static final int[] MLBList = {2013,2019,2018,2009,2020,2018,2017,2021,
            2006,2019,2021,2021,2019,2014,2014};
    private static final String[] userChosen ={"jose alvarez","mauricio dubon","steven duggar","buster posey","caleb baragar","tyler beede","john brebbia","kervin castro",
            "alex cobb","joey bart","curt casali","thairo estrada","mike yastrzemski","austin slater","tommy la stella"};
    //declare player
    private static final Player alvarez = new Player() ;
    private static final Player dubon = new Player() ;
    private static final Player duggar= new Player() ;
    private static  final Player posey = new Player() ;
    private static  final Player baragar = new Player() ;
    private static  final Player beede = new Player() ;
    private static  final Player brebbia = new Player() ;
    private static final Player castro = new Player() ;
    private static final Player cobb = new Player() ;
    private static final Player bart = new Player() ;
    private static final Player casali = new Player() ;
    private static final Player estrada = new Player() ;
    private static final Player yastrzemski = new Player() ;
    private static final Player slater = new Player() ;
    private static final Player stella = new Player() ;




    private static final Player[] playerList = {alvarez,dubon,duggar,posey,baragar,beede,brebbia,castro,
            cobb,bart,casali,estrada,yastrzemski,slater,stella};
    private static final Player fav= new Player();

    public static void test(){
        Scanner input = new Scanner (System.in);
        String userFavPlayer ="";
        int importantIndex=0;
        for (int i=0;i<numberList.length;i++){
            playerList[i].setFullName(nameList[i]);
            playerList[i].setNumber(numberList[i]);
            playerList[i].setPosition(positionList[i]);
            playerList[i].setMlDebut(MLBList[i]);
            playerList[i].setBats(batsList[i]);
            playerList[i].setThrow(throwList[i]);
            Player.setUserChosen(userChosen[i]);


        }
        boolean define = false;
        int count=0;
        while (!define){
            try{
                String text1 ;
                String text2;

                if (Language.getMainLanguage().equals("alien")){
                    text1 =Language.getAlien().repeat(2);
                    text2=Language.getAlien().repeat(numberList.length);

                }else{
                    text1 ="Enter your favorite Player: ";
                    text2=Arrays.toString(nameList);
                }
                System.out.println(text1+text2);
                userFavPlayer = input.nextLine().toLowerCase();
                for (int p=0;p<numberList.length;p++){
                    if (userFavPlayer.equals(userChosen[p].toLowerCase())){
                        count++;
                    }


                }     if (count==0){
                    throw new Exception();
                } else{
                    //define = true;
                    break;
                }
            }catch(Exception ex){
                String text3;

                if (Language.getMainLanguage().equals("alien")){
                    text3 =Language.getAlien();
                }else{
                    text3="Please enter a valid Player!";
                }System.out.println(text3);

            }

        }
        for (int i=0;i<numberList.length;i++){
            if (userFavPlayer.equals(userChosen[i])){
                importantIndex=i;
                break;

            }

        }
        fav.setFullName(nameList[importantIndex]);
        fav.setPosition(positionList[importantIndex]);
        fav.setBats(batsList[importantIndex]);
        fav.setThrow(throwList[importantIndex]);
        fav.setNumber(numberList[importantIndex]);
        fav.setMlDebut(MLBList[importantIndex]);

        //Player.displayDetail();
        playerList[importantIndex].displayDetail();







    }



    //
    // Constructors
    //
    public static String getFullName(){
        return FrontOffice.fav.getFullName();
    }public static int getNumber(){
        return FrontOffice.fav.getNumber();
    }
    public FrontOffice() {



    }public void displayClubInformation(){
        System.out.printf("%-25s %-50s %n", this.getPhrase(0), Club.getName());
        System.out.printf("%-25s %-50s %n", this.getPhrase(1), Club.getShortName());
        System.out.printf("%-25s %-50s %n", this.getPhrase(2), Club.getEstablishYear());
        System.out.printf("%-25s %-50s %n", this.getPhrase(3), Club.getColor());
        System.out.printf("%-25s %-50s %n", this.getPhrase(4), Club.getBallpark());
        System.out.printf("%-25s %-50s %n", this.getPhrase(5), Club.getWorldSeriesTitles());
        System.out.printf("%-25s %-50s %n", this.getPhrase(6), Club.getNLPennants());
        System.out.printf("%-25s %-50s %n", this.getPhrase(7), Club.getDivisionTitles());
        System.out.printf("%-25s %-50s %n", this.getPhrase(8), Club.getWildCardBerths());
        System.out.printf("%-25s %-50s %n", this.getPhrase(9), Club.getOwners());
        System.out.printf("%-25s %-50s %n", this.getPhrase(10), Club.getPresident());
        System.out.printf("%-25s %-50s %n", this.getPhrase(11), Club.getGeneralManager());
        System.out.printf("%-25s %-50s %n", this.getPhrase(12), Club.getManager());
        System.out.println("-".repeat(70));

    }public String getPhrase(int num){
        String[] ClubPhrases =new String[13];
        if (Language.getMainLanguage().equals("alien")){


            ClubPhrases[0]=Language.getAlien();
            ClubPhrases[1]=Language.getAlien();
            ClubPhrases[2]=Language.getAlien();
            ClubPhrases[3]=Language.getAlien();
            ClubPhrases[4]=Language.getAlien();
            ClubPhrases[5]=Language.getAlien();
            ClubPhrases[6]=Language.getAlien();
            ClubPhrases[7]=Language.getAlien();
            ClubPhrases[8]=Language.getAlien();
            ClubPhrases[9]=Language.getAlien();
            ClubPhrases[10]=Language.getAlien();
            ClubPhrases[11]=Language.getAlien();
            ClubPhrases[12]=Language.getAlien();

        }else{

            ClubPhrases[0]="Club: ";
            ClubPhrases[1]="Short Name: ";
            ClubPhrases[2]="Established in: ";
            ClubPhrases[3]="Colors: ";
            ClubPhrases[4]= "Ballpark: ";
            ClubPhrases[5]="World Series Titles: ";
            ClubPhrases[6]= "NL Pennants: ";
            ClubPhrases[7]="Division Titles: ";
            ClubPhrases[8]="Wild Card Berths: ";
            ClubPhrases[9]="Owners: ";
            ClubPhrases[10]="President: ";
            ClubPhrases[11]="General Manager: ";
            ClubPhrases[12]="Manager: ";
        }


        return ClubPhrases[num];

    }

    //
    // Instance Methods
    //

    //
    // Language
    //

}
