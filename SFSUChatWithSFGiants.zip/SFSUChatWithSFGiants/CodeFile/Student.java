/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Student.java
 * Author: Duc Ta
 * Author: <First Name> <Last Name>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

//import java.util.ArrayList;


public final class Student extends Person {

    //
    // Instance Data Fields
    //
    private static int NumberOfStudent=0;
    private static String emailAddress;
    //private static ArrayList<Student> ListOfStudent = new ArrayList<Student>();
    //
    // Constructors
    //
    public Student(String firstName, String lastName) {
        super(firstName, lastName);
        NumberOfStudent ++;
        //setListOfStudent();



    }public Student(){
        NumberOfStudent ++;

    }
    public static int getNumberOfStudent(){
        return Student.NumberOfStudent;
    } public  void setEmailAddress(String email){
        this.emailAddress=email;
    }public  String getEmailAddress(){
        return this.emailAddress;
    }public String getFullName(){
        return this.getFirstName()+" "+this.getLastName();
    }public void setFullName(String name){
        this.setFirstName(name);
        this.setLastName(name);
    }


    /**
     *
     * @param name
     */


    //
    // Instance Methods
    //

    //
    // Additional Methods
    //

    //
    // Language
    //

    //
    // Override
    //

    @Override
    public void sayGreeting(String name) {
        System.out.println("Hello "+name +", I am a Student"); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}