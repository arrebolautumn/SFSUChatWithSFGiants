/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment02PartB;



// project structure and then change the language level
public sealed abstract class Person implements Greeting permits Student, Player, President, GeneralManager, Manager{

    //
    // Instance Data Fields
    //
    private String firstName;
    private String lastName;
    private static int NumberOfPerson=0;


    //
    // Constructors
    //
    public Person(String firstName, String lastName) {
        setFirstName(firstName);
        setLastName(lastName);
        NumberOfPerson++;

    }public Person(){
        NumberOfPerson ++;
    }

    // Instance Methods
    public void setFirstName(String name){
        this.firstName = name;
    }public String getFirstName(){
        return this.firstName;
    }
    public void setLastName(String name){
        this.lastName = name;
    }public String getLastName(){
        return this.lastName;
    } public static int  getNumberOfPerson(){
        return Person.NumberOfPerson;
    }
    @Override
    public String toString(){
        return "name " + firstName +" " + lastName ;
    }
    //
    // Language
    //

    //
    // @override
    //

}

