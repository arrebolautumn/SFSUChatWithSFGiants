/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: QuestionAnswer.java
 * Author: Duc Ta
 * Author: <First Name> <Last Name>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

public final class QuestionAnswer {

    //
    // Instance Data Fields
    //
    private String question;
    private String answer;
    private String correctAnswer;
    //
    // Constructors
    //
    public QuestionAnswer() {

    }

    //
    // Instance Method
    //
    public String getQuestion(){
        return this.question;
    }public void setQuestion(String question){
        this.question=question;
    }public void setAnswer(String ans){
        this.answer =ans;

    }public String getAnswer(){
        return this.answer;
    }public void setCorrectAnswer(String correctAns){
        this.correctAnswer  = correctAns;
    }public String getCorrectAnswer(){
        return this.correctAnswer;
    }
    //
    // Language
    //

    //
    // Override
    //
}