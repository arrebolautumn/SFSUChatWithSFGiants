/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Player.java
 * Author: Duc Ta
 * Author: <First Name> <Last Name>
 * **********************************************
 */
package assignment02PartB;

// Please organize all the given files in 1 same package

import java.util.ArrayList;

// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

public final class Player extends Person {

    // Instance Data Fields
    private  final String club = "San Francisco Giants";
    private String position ;
    private  int number;
    private  String bats ;
    private  String Throw;
    private int MLBDebut;
    private static int NumberOfPlayer=0;
    private static ArrayList<Player> listOfPlayer = new ArrayList<>();
    private String fullName;
    private static String userChosen;

    // Constructors
    //
    public Player(String firstName, String lastName, String position, int number, String bats, String Throw, int MLBDebut) {
        super.setFirstName(firstName);
        super.setLastName(lastName);
        setBats(bats);
        setMlDebut(MLBDebut);
        setNumber(number);
        setPosition(position);
        setThrow(Throw);
        //listOfPlayer.add();

        NumberOfPlayer ++;

    }public Player(){
        NumberOfPlayer ++;

    }public static void addPlayer(Player player){
        Player.listOfPlayer.add(player);

    }public static String[] displayListOfPlayer(){
        String[] nameOfPlayer=new String[listOfPlayer.size()];
        for (int i=0;i<listOfPlayer.size();i++){
            nameOfPlayer[i]=listOfPlayer.get(i).getFullName();


        }
        return nameOfPlayer;

    }
    //
    // Instance Methods
    //

    public void setPosition(String position){
        this.position = position;
    }public String getPosition(){
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();
        }else{
            need =this.position;
        }return need;
    }
    public void setNumber(int number){
        this.number = number;
    }public int getNumber(){
        return this.number;
    }
    public void setBats(String bats){
        this.bats = bats;
    }public String getBats(){
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();
        }else{
            need =this.bats;
        }return need;
    }

    public void setThrow(String Throw){

        this.Throw = Throw;
    }public String getThrow(){
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();
        }else{
            need =this.Throw;
        }return need;
    }

    public void setMlDebut(int MLBDebut){
        this.MLBDebut = MLBDebut;
    }public int getMLBDebut(){
        return this.MLBDebut;
    }public static int getNumberOfPlayer(){
        return Player.NumberOfPlayer;
    }public  String getClub(){
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();
        }else{
            need =this.club;
        }return need;
    }    public String getFullName(){
        String need;
        if (Language.getMainLanguage().equals("alien")){
            need = Language.getAlien();
        }else{
            need =this.fullName;
        }return need;
    }public void setFullName(String name){
        if (Language.getMainLanguage().equals("alien")){
            this.fullName = Language.getAlien();
        }else{
            this.fullName =name;
        }
    }public static void setUserChosen(String name){
        Player.userChosen =name;
    }



    //
    // Additional Instance Methods
    //

    //
    // Language
    //

    //
    // @Override
    //


    @Override
    public void sayGreeting(String string) {
        super.sayGreeting();
        System.out.println("Hello I am a Player");
    }

    public void displayDetail() {
        System.out.println("-".repeat(70));

        System.out.printf("%-25s %-50s %n", this.getPhrase(0), this.getFullName());
        System.out.printf("%-25s %-50s %n", this.getPhrase(1), this.getClub());
        System.out.printf("%-25s %-50s %n", this.getPhrase(2), this.getPosition());
        System.out.printf("%-25s %-50s %n", this.getPhrase(3), this.getNumber());
        System.out.printf("%-25s %-50s %n", this.getPhrase(4), this.getBats());
        System.out.printf("%-25s %-50s %n", this.getPhrase(5), this.getThrow());
        System.out.printf("%-25s %-50s %n", this.getPhrase(6), this.getMLBDebut());
        System.out.println("-".repeat(70));
    }public String getPhrase(int num){
        String[] playerPhrases = new String[7];
        //{"Player: ","Club: ","Position: ", "Number: ","Bats: ","Throws:","MLB Debut: "};
        if (Language.getMainLanguage().equals("alien")){
            playerPhrases[0]=Language.getAlien();
            playerPhrases[1]=Language.getAlien();
            playerPhrases[2]=Language.getAlien();
            playerPhrases[3]=Language.getAlien();
            playerPhrases[4]=Language.getAlien();
            playerPhrases[5]=Language.getAlien();
            playerPhrases[6]=Language.getAlien();

        }else{
            playerPhrases[0]="Player: ";
            playerPhrases[1]="Club: ";
            playerPhrases[2]="Position: ";
            playerPhrases[3]="Number: ";
            playerPhrases[4]="Bats: ";
            playerPhrases[5]="Throws:";
            playerPhrases[6]="MLB Debut: ";



        }
        return playerPhrases[num];
    }
}
