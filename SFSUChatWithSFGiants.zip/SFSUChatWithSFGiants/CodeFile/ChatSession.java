/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment02PartB;
import java.util.*;
/**
 // The color that has always been displayed is from Color class

 * @author lien
 */
public class ChatSession {

    private static University newUniversity;
    private Student newStudent = new Student();
    public static StdOutStdErrTee stdOutStdErrTee = new StdOutStdErrTee();

    private Timer timeZone = new Timer(Timer.getUserTimeZone());


    public ChatSession(Club club, University university) {
        //  Static Data Fields
//ChatSession.club = club;

// The color that has always been displayed is from Color class
        //
        // Instance Data Fields
        //

        //
        // Constructors
        //
    }

    //
    // Instance Methods
    //

    //
    // Additional Instance Methods
    //
    private void startChatSession() {

        //System.out.println("SF Giants: Welcome to the SAN FRANCISCO GIANTS!");
        //Language.displayBrokenLine();
        Scanner input = new Scanner(System.in);

        String need;
        if (Language.getMainLanguage().equals("alien")) {
            need = Language.getAlien();

        } else {
            need = "Chat session started.";
        }
        String combine= timeZone.getDateFormat()+" - "+need;
        System.out.println(timeZone.getDateFormat()+" - "+need);


        System.out.println(" ");
        String text2;
        if (Language.getMainLanguage().equals("alien")) {
            text2 = Language.getAlien().repeat(5);
        } else {
            text2 = "SF Giants: Welcome to the SAN FRANCISCO GIANTS!";

        }

        System.out.println(text2);
        System.out.println("-".repeat(70));

        FrontOffice fo = new FrontOffice();
        fo.displayClubInformation();
        String userInputName;
        String need1;
        if (Language.getMainLanguage().equals("alien")) {
            need1 = Language.getAlien();

        } else {
            need1 = "SF Giants: Your first and last name please: ";
        }
        System.out.print(need1);
        userInputName = input.nextLine();


        String[] words = userInputName.split(" ");// split word between each space
        String[] userNameArray = new String[words.length];

        System.arraycopy(words, 0, userNameArray, 0, words.length); //System.out.print(userNameArray[i]); // testing and CORRECT
// create Student Obj (newStudent)
        try {
            newStudent = new Student(userNameArray[0], userNameArray[1]);
            newStudent.setFirstName(userNameArray[0]);
            newStudent.setLastName(userNameArray[1]);
        } catch (java.lang.ArrayIndexOutOfBoundsException ex) {
            newStudent.setFullName(userInputName);
        }

        String need2;
        if (Language.getMainLanguage().equals("alien")) {
            need2 = Language.getAlien();

        } else {
            need2 = "SF Giants: Your school email address please: ";
        }
        System.out.print(need2);
        String emailAddress = input.nextLine();
        newStudent.setEmailAddress(emailAddress);
        String need4;
        if (Language.getMainLanguage().equals("alien")) {
            need4 = Language.getAlien();
        } else {
            need4 = ": Welcome to my university!";
        }
        Receipt receipt = new Receipt(userInputName, emailAddress);
        stdOutStdErrTee.writeToReceiptFile(combine);
        stdOutStdErrTee.startReceiptLog();
        System.out.println(Color.getBackground() + Color.getYellow() + newStudent.getFirstName() + " " + newStudent.getLastName() + Color.getReset() + need4);
        System.out.println("-".repeat(70));

//create a University Obj
        newUniversity = new University("SF State");
        newUniversity.displayAbout();
        System.out.println(" ");
        String need3;
        if (Language.getMainLanguage().equals("alien")) {
            need3 = Language.getAlien();

        } else {
            need3 = "SF Giants: Thank you. We are connecting you with our player ....";
        }
        System.out.println(need3);
        System.out.println(". . . . . ");
        System.out.println("-".repeat(70));


    }

    private void connectChatters() {
        Scanner input = new Scanner(System.in);

        // create new Player Obj
        //String need3;
        FrontOffice.test();
        boolean define = false;

        while (define == false) {

            System.out.println("\n" + "-".repeat(70) + "\n");

            break;


        }

    }

    private void chat() {

        Scanner input = new Scanner(System.in);
        String text1;
        String text2;
        String text3;
        String text4;
        String text5;
        String text6;
        String text7;
        String text8;
        String text9;
        String text10;
        String text11;
        String text12;
        String text13;
        String text14;
        String text15;
        String text16;

        if (Language.getMainLanguage().equals("alien")) {
            text1 = Language.getAlien();
            text2 = Language.getAlien();
            text3 = Language.getAlien();
            text4 = Language.getAlien();
            text5 = Language.getAlien();
            text6 = Language.getAlien();
            text7 = Language.getAlien();
            text8 = Language.getAlien();
            text9 = Language.getAlien();
            text10 = "\n \t " + "[1] " + Language.getAlien() + " \n\t [2] " + Language.getAlien() + "\n\t [3] " + Language.getAlien();
            text11 = Language.getAlien();
            text12 = Language.getAlien();
            text13 = Language.getAlien();
            text14 = Language.getAlien();
            text15 = Language.getAlien();
            text16 = Language.getAlien();


        } else {
            text1 = ": Hello ";
            text2 = ". C-O-N-G-R-A-T-U-L-A-T-I-O-N-S!";
            text3 = " Way to go!";
            text4 = "Likewise, ";
            text5 = ". Very nice chatting w/ you.";
            text6 = ": How many SF Giants Thank You cards would you like to order?";
            text7 = "Please enter an INTEGER. ";
            text8 = " tries left";
            text9 = "In 3 lines, please provide";
            text10 = "\n \t [1] Recipient name \n\t [2] Art symbol (a character)\n\t [3] Message to recipient";
            text11 = "Card #";
            text12 = " Thanks, ";
            text13 = ". Please confirm your order: ";
            text14 = "Thank you again, ";
            text15 = ". See you at your graduation ceremony!";
            text16 = "San Francisco State University";
        }

        System.out.println(FrontOffice.getFullName() + ", " + FrontOffice.getNumber() + text1 + newStudent.getFirstName() + text2);
        System.out.println(FrontOffice.getFullName() + ", " + FrontOffice.getNumber() + ": " + Color.getBackground() + Color.getYellow() + text16 + Color.getReset() + text3);
        System.out.print(Color.getBackground() + Color.getYellow() + newStudent.getFullName() + ": " + Color.getReset());
        input.nextLine();
        System.out.println(FrontOffice.getFullName() + ", " + FrontOffice.getNumber() + ": " + text4 + newStudent.getFirstName() + text5);
        System.out.println(FrontOffice.getFullName() + ", " + FrontOffice.getNumber() + text6);
        int Input2 = 0;
        String num;
        int tryTime = 3;
        boolean cont = false;
        boolean define = false;
        while (!define) {
            System.out.print(Color.getBackground() + Color.getYellow() + newStudent.getFullName() + ": " + Color.getReset());
            num = input.nextLine();
            try {
                if (tryTime == 0) {
                    StdOutStdErrTee file = new StdOutStdErrTee();
                    file.stopLog();

                    break;

                }
                Input2 = Integer.parseInt(num);
                define = true;
                cont = true;

            } catch (NumberFormatException ex) {
                System.out.print(text7);
                System.out.println(tryTime + text8);
                tryTime--;

            }


        }
        if (cont){
            // out of while loop

            Card.setNumberOfCard(Input2);

        System.out.println(FrontOffice.getFullName() + ", " + FrontOffice.getNumber() + ": " + text9 + text10);

        // create an array of Card
        Card card1 = new Card();
        Card card2 = new Card();
        Card card3 = new Card();

        Card[] arrayOfCard = {card1, card2, card3};
        for (int countForSendingCard = 0; countForSendingCard < Input2; countForSendingCard++) {
            int tagOfCard = countForSendingCard + 1;


            System.out.println(FrontOffice.getFullName() + ", " + FrontOffice.getNumber() + ": " + text11 + tagOfCard);
            System.out.print(newStudent.getFullName() + ": [1] ");
            String Input3Recipient = input.nextLine();
            arrayOfCard[countForSendingCard].setRecipient(Input3Recipient);
            arrayOfCard[countForSendingCard].setSenderFirstName(newStudent.getFirstName());
            arrayOfCard[countForSendingCard].setSenderEmail(newStudent.getEmailAddress());

            System.out.print(newStudent.getFullName() + ": [2] ");
            char Input4ArtSymbol = input.nextLine().charAt(0);
            arrayOfCard[countForSendingCard].setArtSymbol(Input4ArtSymbol);


            System.out.print(newStudent.getFullName() + ": [3] ");
            String Input5Message = input.nextLine();
            arrayOfCard[countForSendingCard].setMessage(Input5Message);


            stdOutStdErrTee.writeToReceiptFile(Input3Recipient);
            stdOutStdErrTee.writeToReceiptFile(Character.toString(Input4ArtSymbol));
            stdOutStdErrTee.writeToReceiptFile(Input5Message);
            stdOutStdErrTee.writeToReceiptFile(" ");



        }


        System.out.println(FrontOffice.getFullName() + ", " + FrontOffice.getNumber() + ": " + text12 + newStudent.getFirstName()
                + text13);
        System.out.println(" ");

        for (int countForSendingCard = 0; countForSendingCard < Input2; countForSendingCard++) {
            arrayOfCard[countForSendingCard].getCard();
            System.out.println(" \n");

        }
        System.out.print(newStudent.getFullName() + ": ");
        input.nextLine();
        System.out.println(FrontOffice.getFullName() + ", " + FrontOffice.getNumber() + ": " + text14 + newStudent.getFirstName()
                + text15);


    }else{
            System.out.println("Sorry, we will redirect you to another part!");
        }

}
    private void runQuiz() {
        String text1;
        String text2;


        System.out.println(" ");
        if (Language.getMainLanguage().equals("alien")){
            text1=Language.getAlien().repeat(3);
            text2=Language.getAlien();
        }else{
            text1="*** FREE TICKETS to SF GIANTS Games *** _ 1 miss allowed _";
            text2="Chat session ended.";
        }
        System.out.println(text1);
        Quiz.setStudentName(newStudent.getFullName());
        Quiz.AnswerThis();
        System.out.println("-".repeat(70));
        System.out.println(timeZone.getDateFormat()+" - "+text2);
        stdOutStdErrTee.writeToReceiptFile(" ");

        stdOutStdErrTee.writeToReceiptFile(timeZone.getDateFormat()+" - "+text2);


    }
    private void stopChatSession() {
    }
    public void runChatSession()  {
        startChatSession() ;
        connectChatters();
        chat();
        runQuiz();
        stopChatSession();

    }
    //
    // Language
    //
}



